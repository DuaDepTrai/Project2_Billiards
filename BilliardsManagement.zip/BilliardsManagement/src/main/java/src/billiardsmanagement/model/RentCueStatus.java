package src.billiardsmanagement.model;

public enum RentCueStatus {
    Rented, Returned
}
